package com.neusoft.elm;

public class ElmAdminEntry {

}
